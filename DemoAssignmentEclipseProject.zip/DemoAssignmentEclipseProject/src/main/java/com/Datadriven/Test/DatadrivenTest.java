package com.Datadriven.Test;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import com.excel.utility.Xls_Reader;

public class DatadrivenTest {

	public static void main(String[] args) {
	
	Xls_Reader Reader = new Xls_Reader("D:\\Assignment\\DemoAssignmentEclipseProject\\src\\main\\java\\com\\TestData\\AssignmentTestdata.xlsx");
		 
	    String Source = Reader.getCellData("Assignment1","Source", 2);
		String Destination = Reader.getCellData("Assignment1", "Destination", 2);
		String Name  = Reader.getCellData("Assignment1", "Name", 2);
     	String Address = Reader.getCellData("Assignment1","Address",2);
		String City = Reader.getCellData("Assignment1","City",2);
        String State = Reader.getCellData("Assignment1","State",2);
      
        String ZipCode = Reader.getCellData("Assignment1", "ZipCode", 2);
        String CardType = Reader.getCellData("Assignment1","CardType",2);
        String CardNumber = Reader.getCellData("Assignment1","CreditCardNumber",2);
        String CardExpiryMonth = Reader.getCellData("Assignment1","CardExpirtyMonth",2);
        String CardExpiryYear = Reader.getCellData("Assignment1","CardExpirtyYear",2);
        String NameonCard = Reader.getCellData("Assignment1","NameonCard",2);
				   
		

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\daggu\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://blazedemo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		Select FromPort= new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
		FromPort.selectByVisibleText(Source);
		
		Select Toport = new Select(driver.findElement(By.xpath("//select[@name='toPort']")));
		Toport.selectByVisibleText(Destination);
		
		driver.findElement(By.xpath("//input[@type=\"submit\"]")).click();
		 
		driver.findElement(By.xpath("//input[@value=\"Choose This Flight\"]")).click();
		
		
		driver.findElement(By.id("inputName")).clear();
		driver.findElement(By.id("inputName")).sendKeys(Name);
		
		driver.findElement(By.id("address")).clear();
		driver.findElement(By.id("address")).sendKeys(Address);
		
		driver.findElement(By.id("city")).clear();
		driver.findElement(By.id("city")).sendKeys(City);
		
		driver.findElement(By.id("state")).clear();
		driver.findElement(By.id("state")).sendKeys(State);
		
		driver.findElement(By.id("zipCode")).clear();
		driver.findElement(By.id("zipCode")).sendKeys(ZipCode);
		
		Select Type = new Select(driver.findElement(By.xpath("//select[@name='cardType']")));
		Type.selectByVisibleText(CardType);
		
		driver.findElement(By.id("creditCardNumber")).clear();
		driver.findElement(By.id("creditCardNumber")).sendKeys(CardNumber);
		
		driver.findElement(By.id("creditCardMonth")).clear();
		driver.findElement(By.id("creditCardMonth")).sendKeys(CardExpiryMonth);
		
		driver.findElement(By.id("creditCardYear")).clear();
	    driver.findElement(By.id("creditCardYear")).sendKeys(CardExpiryYear);
	    
	    driver.findElement(By.id("nameOnCard")).clear();
		driver.findElement(By.id("nameOnCard")).sendKeys(NameonCard);
		
		driver.findElement(By.xpath("//label[@class=\"checkbox\"]")).click(); 
		//driver.findElement(By.xpath("//input[@value=\"Purchase Flight\"]")).click();
		
	}

}
